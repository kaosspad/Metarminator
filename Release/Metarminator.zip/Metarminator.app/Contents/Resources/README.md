Metarminator
============

An iTunes Metadata editor.

[Project Site](https://github.com/x43x61x69/Metarminator)

![Screenshot](https://dl.dropboxusercontent.com/s/h4r6j0qzofwsffx/Metarminator.png)


Description
-----------

*The source code served as an example, it is, by no means, a commercial grade product. It might contain errors or flaws, and it was created for demonstration purpose only.*

Metarminator allows you to batch edit iTunes Metadata of your iTunes musics and videos.

It was originally [AtomicParsleyGUI](https://github.com/x43x61x69/AtomicParsleyGUI), now it use AVFoundation framework to read and write iTunes Metadata instead of AtomicParsley.

*For donations, you can send Amazon.com/.co.uk gift cards to contact@reversi.ng.*

Bug report? Please do it [here](https://github.com/x43x61x69/Metarminator/issues).


Changelog
---------

v0.2.1:
* Bug fix.

v0.2:
* Bug fix - Codesign issue.

v0.1.1:
* Bug fix - Silents on launch update check.

v0.1:
* Initial release.


License
-------

Copyright (C) 2014  Cai, Zhi-Wei.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

Icon designed by [Turbomilk](http://www.turbomilk.com). (info@turbomilk.com)
